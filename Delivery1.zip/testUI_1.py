import sys
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6 import uic

class MainWindow(QtWidgets.QMainWindow):

    def __init__(self):
        super().__init__()
        uic.loadUi("EarthquakeDetection.ui", self)

app = QtWidgets.QApplication(sys.argv)
window = MainWindow()
# window.show()
app.exec()
