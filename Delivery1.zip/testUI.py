import sys
from PyQt6 import QtWidgets, uic

class Window(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi("EarthquakeDetection.ui", self)
        

app = QtWidgets.QApplication(sys.argv)
window = Window()
window.show()
app.exec()
