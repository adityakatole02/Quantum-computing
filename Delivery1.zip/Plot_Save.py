import pandas as pd
import matplotlib.pyplot as plt

# Replace 'data.csv' with the actual path to your CSV file
df = pd.read_csv('seg_00030f.csv')

# Assuming your CSV file has a column named 'index' and 'acoustic_data'

plt.figure(figsize=(10, 3))  # Adjust the figure size as needed
plt.plot(df['acoustic_data'], label='Acoustic Data')

plt.xlabel('Index')
plt.ylabel('Acoustic Data')
plt.title('Acoustic Data vs. Index')
plt.legend()

# Save the plot as an image (e.g., in PNG format)
plt.savefig('acoustic_data_plot.png')

# Show the plot (optional)
plt.show()
