import sys
from PyQt6.QtCore import Qt
from PyQt6 import QtWidgets, uic
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog
from PyQt6.QtWidgets import QApplication, QWidget, QLabel
from PyQt6.QtGui import QIcon, QFont, QPixmap, QMovie, QRegion
from PyQt6.QtCore import Qt

# import matplotlib.pyplot as plt
# from tqdm.notebook import tqdm
# from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
# from sklearn.svm import NuSVR
# from sklearn import svm
from scipy import stats
# import numpy as np
# import pandas as pd
# import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import joblib
import os

import pandas as pd
import matplotlib.pyplot as plt

global svm_model,scaler
# Load the trained SVM model
svm_model = joblib.load('model_svm.pkl')

# Load the scaler used for data preparation
scaler = joblib.load('scaler.pkl')

def calc_change_rate(x):
    change = (np.diff(x) / x[:-1]).values
    change = change[np.nonzero(change)[0]]
    change = change[~np.isnan(change)]
    change = change[change != -np.inf]
    change = change[change != np.inf]
    return np.mean(change)

def add_trend_feature(arr, abs_values=False):
    idx = np.array(range(len(arr)))
    if abs_values:
        arr = np.abs(arr)
    lr = LinearRegression()
    lr.fit(idx.reshape(-1, 1), arr)
    return lr.coef_[0]

def featuresx(x_data, X, segment):
    X.loc[segment, 'ave'] = x_data.mean()
    X.loc[segment, 'std'] = x_data.std()
    X.loc[segment, 'max'] = x_data.max()
    X.loc[segment, 'min'] = x_data.min()
    
    X.loc[segment, 'q01'] = np.quantile(x_data,0.01)
    X.loc[segment, 'q05'] = np.quantile(x_data,0.05)
    X.loc[segment, 'q95'] = np.quantile(x_data,0.95)
    X.loc[segment, 'q99'] = np.quantile(x_data,0.99)
    
    X.loc[segment, 'mean_change_abs'] = np.mean(np.diff(x_data))
    X.loc[segment, 'mean_change_rate'] = calc_change_rate(x_data)
    X.loc[segment, 'abs_max'] = np.abs(x_data).max()
    X.loc[segment, 'abs_min'] = np.abs(x_data).min()

    X.loc[segment, 'max_to_min'] = x_data.max() / np.abs(x_data.min())
    X.loc[segment, 'max_to_min_diff'] = x_data.max() - np.abs(x_data.min())
    X.loc[segment, 'count_big'] = len(x_data[np.abs(x_data) > 500])
    X.loc[segment, 'sum'] = x_data.sum()

    X.loc[segment, 'abs_trend'] = add_trend_feature(x_data, abs_values=True)
    X.loc[segment, 'abs_mean'] = np.abs(x_data).mean()
    X.loc[segment, 'abs_std'] = np.abs(x_data).std()
    X.loc[segment, 'abs_median'] = np.median(np.abs(x_data))

    X.loc[segment, 'trend'] = add_trend_feature(x_data)
#     X.loc[segment, 'mad'] = x_data.mad()
    X.loc[segment, 'kurt'] = x_data.kurtosis()
    X.loc[segment, 'skew'] = x_data.skew()
    X.loc[segment, 'med'] = x_data.median()
    
    X.loc[segment, 'abs_q95'] = np.quantile(np.abs(x_data),0.95)
    X.loc[segment, 'abs_q99'] = np.quantile(np.abs(x_data),0.99)
    X.loc[segment, 'F_test'], X.loc[segment, 'p_test'] = stats.f_oneway(x_data[:30000],x_data[30000:60000],x_data[60000:90000],x_data[90000:120000],x_data[120000:])
    X.loc[segment, 'av_change_abs'] = np.mean(np.diff(x_data))
        
    return X

def feature_extraction(data,segments):
    print('segments---------')
    print(segments)
    X = pd.DataFrame(index=range(segments), dtype=np.float64)
    print('X : ---------', )
    print(X)
    y = pd.DataFrame(index=range(segments), dtype=np.float64,columns=['time_to_failure'])
    for segment in tqdm(range(segments)):
        seg = data.iloc[segment*rows:segment*rows+rows]
        x_data = pd.Series(seg['acoustic_data'].values)
#         print('x_data--------------')
#         print(x_data)
        y_data = seg['time_to_failure'].values[-1]

        y.loc[segment,'time_to_failure'] = y_data
#         print('segment-----------')
#         print(segment)
        X = featuresx(x_data, X, segment)
#         break
        
        
    return X, y

class Window(QtWidgets.QDialog):
    
    def __init__(self):
        super().__init__()
        uic.loadUi("EarthquakeDetection.ui", self)
        self.FileButton.clicked.connect(self.LoadFile)
        self.PredictButton.clicked.connect(self.PredictCallback)
        # PredictButton
        self.Outlabel.setText('0.0')  



        # self.show()
    def PredictCallback(self):
        global svm_model,scaler, filename
        # seg_id='seg_00030f.csv'

        data_I = pd.read_csv(filename)

        rows_I = 150_000
        segments_I = int(np.floor(data_I.shape[0] / rows_I))

        # create blank df
        X_I = pd.DataFrame(index=range(segments_I), dtype=np.float64) 
        x_data_I = pd.Series(data_I['acoustic_data'].values)



        X_I = featuresx(x_data_I, X_I, segments_I)
        X_I.drop(index=X_I.index[0], axis=0, inplace=True)

        X_I_s = scaler.transform(X_I)
        predictions_I=svm_model.predict(X_I_s)
        print(predictions_I[0])  
        output="{:.2f}".format(predictions_I[0])
        self.Outlabel.setText(output)  





    def LoadFile(self):
        global filename
        print("Clicked!")
        self.Outlabel.setText('0.0')
        filename, _ = QFileDialog.getOpenFileName(self)
        print('filename ' , filename)
        if filename:
            self.PathEdit.setText(filename)
                    # Assuming your CSV file has a column named 'index' and 'acoustic_data'
            df = pd.read_csv(filename)

            plt.figure(figsize=(10, 3))  # Adjust the figure size as needed
            plt.plot(df['acoustic_data'], label='Acoustic Data')

            plt.xlabel('Index')
            plt.ylabel('Acoustic Data')
            plt.title('Acoustic Data vs. Index')
            plt.legend()

            # Save the plot as an image (e.g., in PNG format)
            plt.savefig('acoustic_data_plot.png')
            image_path = "acoustic_data_plot.png"  # Replace with the path to your image file
            pixmap = QPixmap('acoustic_data_plot.png')
            self.image_label.setPixmap(pixmap)



            # Show the plot (optional)
            # plt.show()
        else:
            
            self.PathEdit.setText("Please select valid path !")



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Window()
    window.show()
    app.exec()
